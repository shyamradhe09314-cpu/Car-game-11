const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = 400;
canvas.height = 600;

const roadImg = new Image();
roadImg.src = 'images/road.png';

const car1Img = new Image();
car1Img.src = 'images/car1.png';

const car2Img = new Image();
car2Img.src = 'images/car2.png';

let car1 = { x: 150, y: 500, speed: 5 };
let car2 = { x: 150, y: 50, speed: 5 };

document.addEventListener('keydown', e => {
    if (e.key === 'ArrowLeft') car1.x -= 50;
    if (e.key === 'ArrowRight') car1.x += 50;
    if (e.key === 'a') car2.x -= 50;
    if (e.key === 'd') car2.x += 50;
});

function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(roadImg, 0, 0, canvas.width, canvas.height);

    car2.y += car2.speed;
    if (car2.y > canvas.height) {
        car2.y = -100;
    }

    ctx.drawImage(car1Img, car1.x, car1.y, 50, 100);
    ctx.drawImage(car2Img, car2.x, car2.y, 50, 100);

    if (car1.x < car2.x + 50 &&
        car1.x + 50 > car2.x &&
        car1.y < car2.y + 100 &&
        car1.y + 100 > car2.y) {
        alert("Game Over!");
        document.location.reload();
    }

    requestAnimationFrame(update);
}

update();
